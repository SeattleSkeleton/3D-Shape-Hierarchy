public interface Shape3D {
double getArea();
double getVolume();
String toString();
boolean equals(Object obj);



}
